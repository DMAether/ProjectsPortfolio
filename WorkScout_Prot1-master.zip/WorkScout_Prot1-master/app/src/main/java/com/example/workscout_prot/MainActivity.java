package com.example.workscout_prot;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    //initialize layout elements
    private EditText userText;
    private EditText passText;

    //initialize Database class
    private Database db;
    private Switch passSwitch;

    //very first method run upon app activation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //construct layout elements
        userText = findViewById(R.id.UserText);
        passText = findViewById(R.id.PasswordText);
        passSwitch = findViewById(R.id.passwordSwitch);
        //construct database
        db = new Database(this);
    }

    //show password upon switch (not yet functioning
    public void showPass(View view) {
        if (passSwitch.isChecked()){
            System.out.println("Show");
        } else System.out.println("Hide");
    }

    //switch to SignUp screen/activity upon button press
    public void SignUp(View view){
        Intent intent = new Intent(MainActivity.this, SignUp.class);
        startActivity(intent);
    }

    //sign in upon button press
    public void SignIn(View view) {
        //fetch entered values
        String mail = userText.getText().toString();
        String pass = passText.getText().toString();
        //send credentials to database class to compare entered values to database
        int res = db.SignIn(mail, pass);
        //initialize for later use
        boolean alertShow = true;
        //create dialogue box for confirmation or failure
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Alert!");
        builder.setCancelable(true);
        //check result of database search for credentials
        switch (res){
            case 0:
                //correct credentials, dont show alertdialogue and switch to homepage
                alertShow = false;
                ChooseHome(mail);
                break;
            case 1:
                //no matching email found in database
                System.out.println("Account does not exist");
                builder.setMessage("Account does not exist");
                break;
            case 2:
                //email was found but entered password did not match
                System.out.println("Password does not match");
                builder.setMessage("Password does not match");
                break;
            case 3:
                //unkown error checking credentials
                System.out.println("Sign In failed");
                builder.setMessage("Sign In failed");
                break;
        }
        //show alert dialogue box if signin was unssuccesful
        if(alertShow) {
            builder.setNegativeButton("close", (DialogInterface.OnClickListener) (dialog, which) -> {
                dialog.cancel();
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public void ChooseHome(String mail){
        Cursor resultSet;
        try {
            resultSet = db.FetchAcc(mail);
            resultSet.moveToFirst();
        }catch(SQLException e){
            throw new SQLException();
        }


        if(resultSet.getString(4).equals("Hire")){
            Intent intent = new Intent(MainActivity.this, home_client.class);
            //send email to homepage
            intent.putExtra("Email", mail);
            startActivity(intent);
        } else{
            Intent intent = new Intent(MainActivity.this, WorkHome.class);
            //send email to homepage
            intent.putExtra("Email", mail);
            startActivity(intent);
        }
        db.ClosingDB();
    }
    //temp method for developement
    public void TestSys(View view) {
        Intent intent = new Intent(MainActivity.this, Tester_Temp.class);
        startActivity(intent);
    }
}