package com.example.workscout_prot;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Random;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.JobViewHolder> {

    private Context context;
    private List<Job> jobList;

    // Some vibrant material-style colors
    private final int[] colors = {
            0xFF9C27B0, // Purple
            0xFF2196F3, // Blue
            0xFFF44336, // Red
            0xFFFF9800, // Orange
            0xFF4CAF50  // Green
    };

    public JobAdapter(Context context, List<Job> jobList) {
        this.context = context;
        this.jobList = jobList;
    }

    @Override
    public JobViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_job_card, parent, false);
        return new JobViewHolder(view);
    }

    @Override
    public void onBindViewHolder(JobViewHolder holder, int position) {
        Job job = jobList.get(position);
        holder.clientName.setText(job.clientName);
        holder.description.setText("is looking for a " + job.profession);

        // Set random color for card header and button
        int color = colors[new Random().nextInt(colors.length)];
        holder.cardHeader.setBackgroundColor(color);
        holder.viewOfferBtn.setBackgroundTintList(ColorStateList.valueOf(color));

        // Optional: handle button clicks
        holder.viewOfferBtn.setOnClickListener(v -> {
            // Placeholder for future action
            // Toast.makeText(context, "View " + job.clientName + "'s offer", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return jobList.size();
    }

    public static class JobViewHolder extends RecyclerView.ViewHolder {
        TextView clientName, description;
        Button viewOfferBtn;
        LinearLayout cardHeader;

        public JobViewHolder(View itemView) {
            super(itemView);
            clientName = itemView.findViewById(R.id.job_owner);
            description = itemView.findViewById(R.id.job_description);
            viewOfferBtn = itemView.findViewById(R.id.view_offer_btn);
            cardHeader = itemView.findViewById(R.id.cardHeader);
        }
    }
}