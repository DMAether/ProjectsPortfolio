package com.example.workscout_prot;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SignUp extends AppCompatActivity {
    //initialize variables and layouts
    public Intent intent;
    private CalendarView calender;
    private Button calBTN;
    private String dob;
    private RadioGroup accSelect;
    private TextView fieldView;
    private Spinner spin;
    private String[] arrProf;
    private int yeardb;
    private int monthdb;
    private int daydb;
    private boolean ageChck;
    private Database db;
    private TextView mailText;
    private TextView nameText;
    private TextView passText;
    private String accType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ageChck = false;//initialize age confirmation as true
        intent = getIntent(); //don't remember what this is for but just gonna leave it here
        //configure and set up the calendervierw for selecting date of birth
        calender = findViewById(R.id.calendarSel);
        Calendar calSet = Calendar.getInstance(); //create a calender variable to store initialze date
        calSet.set(2001, Calendar.JANUARY, 1 );
        calender.setDate(calSet.getTimeInMillis()); //set as calenderview date by converting Calander variable to milliseconds
        calender.setVisibility(View.GONE); //make invisible here instead of in xml or it wont work

        //get the initialzed date to write onto button
        long millisDate = calender.getDate();
        Date date = new Date(millisDate);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String formattedDate = sdf.format(date);

        calBTN = findViewById(R.id.CalBTN);
        calBTN.setText(formattedDate);

        //store date and update button text after user has selected a date. also make invisible again
        calender.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            dob = dayOfMonth + "-" + (month + 1) + "-" + year;
            calBTN.setText(dob);
            calender.setVisibility(View.GONE);
            yeardb = year;
            monthdb = month;
            daydb = dayOfMonth;
        });

        accSelect = findViewById(R.id.RDGroup);
        fieldView = findViewById(R.id.fieldView);

        //connect fieldwork selector and add items to it using array and adapter
        spin = findViewById(R.id.spinner);
        arrProf = new String[]{"WoodWork", "Plumbing", "Electrical", "None"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, arrProf);
        spin.setAdapter(adapter);

        //find and store account type, as well as show or hide field spinner after the user checks either work or hire respectivly
        accSelect.setOnCheckedChangeListener((group, checkedId) -> {
            System.out.println(checkedId);
            if(checkedId==2131230747){
                System.out.println(checkedId);
                fieldView.setVisibility(View.VISIBLE);
                spin.setVisibility(View.VISIBLE);
                accType = "Work";
            }else {
                fieldView.setVisibility(View.GONE);
                spin.setVisibility(View.GONE);
                accType = "Hire";
            }
        });

        mailText = findViewById(R.id.MailText);
        nameText = findViewById(R.id.NameText);
        passText = findViewById(R.id.passText);
    }

    //return tyo sign on by pressing X button
    public void Cancel(View view){
        Intent intent = new Intent(SignUp.this, MainActivity.class);
        startActivity(intent);
    }

    //show calander view once date of birth button is pressed
    public void ShowCal(View view){
        calender.setVisibility(View.VISIBLE);
        calender.bringToFront();

    }

    //attempt checks and sing up
    public void SignOps(View view) throws ParseException {
        //get current date
        int todayYear = LocalDate.now().getYear();
        int todayMonth = LocalDate.now().getMonthValue();
        int todayDay = LocalDate.now().getDayOfMonth();

        //check if 19 or older, otherwise show an alert and stop this signOps method
        //needs fixing, works perfectly outside of same month of 19 years ago
        //(if you select todays month exactly 19 years ago, even if the day makes you over 19 it will still view as underage)
        if(todayYear-yeardb>19) {
            ageChck = true;
        } else if(todayYear-yeardb==19 && todayMonth-monthdb>0){
            ageChck = true;
        } else if(todayYear-yeardb==19 && todayMonth-monthdb==0 && todayDay-daydb>=0){
            ageChck = true;
        }else {
            Alert(0);
            return;
        }
        //check if email is already in use
        System.out.println("Checking Email");
        db = new Database(this);

        String mail = mailText.getText().toString(); // get entered
        System.out.println(mail);
        Cursor resultSet = db.FetchAcc(mail);
        //if the returned Cursor has a getCount of zero, then no existing account was found
        //otherwise, this if runs to alert of exisitng account and ends signOps
        if(resultSet.getCount() != 0){
            Alert(1);
            return;
        }
        String name = nameText.getText().toString();
        String password = passText.getText().toString();
        String field = "";
        //get field from spinner ONLY if account is set to work
        if(accType.equals("Work")){
            field = spin.getSelectedItem().toString();
        }

        System.out.println("Creating account");
        //run insert , returns 0 if succesful, otherwise unsuccesful
        int signRun =  db.SignUp(mail, name, password, dob, accType, field);
        if(signRun == 0){
            Alert(3);
            db.ClosingDB();
            //return to sign in
            Intent intent = new Intent(SignUp.this, MainActivity.class);
            startActivity(intent);
        } else Alert(2);
    }

    public void Alert(int value){
        AlertDialog.Builder builder = new AlertDialog.Builder(SignUp.this);
        builder.setTitle("Alert!");
        builder.setCancelable(true);
        switch (value){
            case 0:
                builder.setMessage("You must be 19 or older to sign up");
                break;
            case 1:
                builder.setMessage("Email already registered");
                break;
            case 2:
                builder.setMessage("Error creating account");
                break;
            case 3:
                builder.setMessage("Account created successfully");
                break;
        }
        builder.setNegativeButton("close", (DialogInterface.OnClickListener)(dialog, which) ->{
            dialog.cancel();
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }

}