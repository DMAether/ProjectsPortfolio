package com.example.workscout_prot;

import android.content.Context;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Database extends AppCompatActivity {
    //initialize
    private SQLiteDatabase wsDB;

    public Database(Context context) {
        try {
            //creates new database if not existing (i.e. first time running program
            // otherwise, just connects
            wsDB = context.openOrCreateDatabase("WorkScoutDB",Context.MODE_PRIVATE, null);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public Cursor FetchAcc(String mail){
        Cursor resultSet;
        try {
            wsDB.execSQL("CREATE TABLE IF NOT EXISTS Accounts(Username VARCHAR, Password VARCHAR, Name VARCHAR, Dob DATE, Type VARCHAR, Field VARCHAR);");
            resultSet = wsDB.rawQuery("SELECT * FROM Accounts WHERE Username = '" + mail + "';", null);
        }catch (SQLException e){
            throw new SQLException();
        }

        return resultSet;
    }
    public int SignUp(String mail, String name, String password, String dob, String accType, String field) throws ParseException {
        if(dob != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            java.util.Date date = sdf.parse(dob);
            // java.sql.Date sqlDate = new java.sql.Date(date.getTime()); // no longer needed

            try {
                wsDB.execSQL("CREATE TABLE IF NOT EXISTS Accounts(Username VARCHAR, Password VARCHAR, Name VARCHAR, Dob DATE, Type VARCHAR, Field VARCHAR);");
                wsDB.execSQL("INSERT INTO Accounts(Username, Password, Name, Dob, Type, Field) VALUES ('" + mail + "', '" + password + "', '" + name + "', '" + sdf.format(date) + "', '" + accType + "', '" + field + "');");
            } catch (SQLException e) {
                e.printStackTrace();
                return 1;
            }
        } else return 1;
        return 0;
    }

    public int SignIn(String email, String password){
        int res;
        try {
            Cursor result = wsDB.rawQuery("SELECT * FROM Accounts WHERE Username = '" + email + "';", null);
            if(result.getCount() != 0){ // check if no account already exists from mail
                result.moveToFirst();
                if(password.equals(result.getString(1))){ //check if paswsword matches
                    res = 0;
                } else res = 2;
            }else res = 1;
        }catch (SQLException e){
            res = 3;
        }
        return res;
    }

    public void ClosingDB(){
        wsDB.close();
    } //close db connection

    //for developement purposes
    public Cursor GetAll(){
        Cursor resultTester = null;
        try {
            resultTester = wsDB.rawQuery("SELECT * FROM Accounts;", null);

        }catch(SQLException e){
            System.out.println("Error");
        }
        return resultTester;

    }

}
