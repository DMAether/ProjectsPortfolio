package com.example.workscout_prot;

public class Job {
    public String clientName;
    public String profession;

    public Job(String clientName, String profession) {
        this.clientName = clientName;
        this.profession = profession;
    }
}