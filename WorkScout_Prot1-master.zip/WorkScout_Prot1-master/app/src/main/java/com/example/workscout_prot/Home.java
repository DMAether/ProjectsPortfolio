package com.example.workscout_prot;

import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Home extends AppCompatActivity {

    public String mail;
    public Database db;
    private TextView greeting;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        if(getIntent().getExtras() != null){
            mail = getIntent().getStringExtra("Email");
        }

        db = new Database(this);
        greeting = findViewById(R.id.greetingView);
        greetingSet(db, greeting);
        db.ClosingDB();
    }

    private void greetingSet(Database db, TextView greeting){
        Cursor resultSet = db.FetchAcc(mail);
        String name = null;
        try {
            resultSet.moveToFirst();
            name = resultSet.getString(2);
        } catch (SQLException e){
            throw new SQLException();
        }
        greeting.setText("Hi, " + name);
    }
}