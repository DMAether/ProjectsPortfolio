package com.example.workscout_prot;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Tester_Temp extends AppCompatActivity {
    private EditText num;
    public Database dbTest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tester_temp);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        num = findViewById(R.id.editTextText);
        dbTest = new Database(this);
    }

    public void TestData(View view){
        Cursor resultSet = dbTest.GetAll();
        resultSet.moveToFirst();
        while (!resultSet.isAfterLast()){
            System.out.println(resultSet.getString(0) + ", " + resultSet.getString(1) + ", " + resultSet.getString(2)+ ", " + resultSet.getString(3) + ", " + resultSet.getString(4) + ", " + resultSet.getString(5));
            resultSet.moveToNext();
        }
    }
}