package com.example.workscout_prot;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class WorkHome extends AppCompatActivity {

    private TextView greetingView, professionView;
    private RecyclerView jobsRecyclerView;
    private Database db;
    private String email; // To track the logged-in user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_home);

        // 1. Get passed email
        email = getIntent().getStringExtra("Email");

        // 2. Initialize views
        greetingView = findViewById(R.id.greetingView);
        professionView = findViewById(R.id.professionView);
        jobsRecyclerView = findViewById(R.id.jobsRecyclerView);

        // 3. Load contractor data
        db = new Database(this);
        Cursor result = db.FetchAcc(email);
        if (result.moveToFirst()) {
            String name = result.getString(2);   // "Name" column
            String profession = result.getString(5); // "Field" column
            greetingView.setText("Hi, " + name);
            professionView.setText(profession);
        }
        db.ClosingDB();

        // 4. Populate dummy job cards (use real data later)
        List<Job> jobs = new ArrayList<>();
        jobs.add(new Job("Lucas", "Woodworker"));
        jobs.add(new Job("Mia", "Electrician"));
        jobs.add(new Job("Aiden", "Plumber"));

        JobAdapter adapter = new JobAdapter(this, jobs);
        jobsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        jobsRecyclerView.setAdapter(adapter);
    }
}